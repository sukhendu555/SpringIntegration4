
package com.integration.json.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "getOfferResponse"
})
@XmlRootElement
public class OfferJsonResponse {

    @JsonProperty("getOfferResponse")
    @XmlElement
    private GetOfferResponse getOfferResponse;
  
    @JsonProperty("getOfferResponse")
    public GetOfferResponse getGetOfferResponse() {
        return getOfferResponse;
    }

    @JsonProperty("getOfferResponse")
    public void setGetOfferResponse(GetOfferResponse getOfferResponse) {
        this.getOfferResponse = getOfferResponse;
    }

}
