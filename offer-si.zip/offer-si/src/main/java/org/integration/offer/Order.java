package org.integration.offer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mark Fisher
 * @author Marius Bogoevici
 * @author Tom McCuch
 * @author Gunnar Hillert
 */
public class Order implements Serializable{

	private static final long serialVersionUID = 1L;

	private List<OfferItem> OfferItems = new ArrayList<OfferItem>();

	/** the order number used for tracking */
	private int number;

	// Default constructor required by Jackson Java JSON-processor
	public Order() {}

	public Order(int number) {
		this.number = number;
	}

	public void addItem(OfferType drinkType, int shots, boolean iced) {
		this.OfferItems.add(new OfferItem(this.number, drinkType, shots, iced));
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public List<OfferItem> getItems() {
		return this.OfferItems;
	}

	public void setItems(List<OfferItem> OfferItems) {
		this.OfferItems = OfferItems;
	}
}
