package org.integration.offer;

import java.io.Serializable;

/**
 * @author Kundan
 */
public enum OfferType implements Serializable{

	EMS,
	FVT,
	COPS,
	Graph

}
