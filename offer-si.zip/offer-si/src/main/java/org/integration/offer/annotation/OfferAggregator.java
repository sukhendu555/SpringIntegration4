package org.integration.offer.annotation;

import java.util.List;

import org.integration.offer.Delivery;
import org.integration.offer.Offer;
import org.springframework.integration.annotation.Aggregator;
import org.springframework.integration.annotation.CorrelationStrategy;
import org.springframework.integration.annotation.MessageEndpoint;

/**
 * @author Marius Bogoevici
 */
@MessageEndpoint
public class OfferAggregator {

	@Aggregator(inputChannel = "preparedOffer", outputChannel = "deliveries")
	public Delivery prepareDelivery(List<Offer> drinks) {
		return new Delivery(drinks);
	}

	@CorrelationStrategy
	public int correlateByOrderNumber(Offer drink) {
		return drink.getOrderNumber();
	}

}
