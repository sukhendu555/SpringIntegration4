package com.integration.ws.gateway;

import com.integration.json.request.OfferJsonRequest;
import com.integration.json.response.OfferJsonResponse;
import org.springframework.integration.annotation.MessagingGateway;

/**
 *
 * @author
 */
@MessagingGateway(name = "entryGateway", defaultRequestChannel = "requestChannel")
public interface OfferService {
    
     public OfferJsonResponse findOffer(OfferJsonRequest offerRequest);
}
