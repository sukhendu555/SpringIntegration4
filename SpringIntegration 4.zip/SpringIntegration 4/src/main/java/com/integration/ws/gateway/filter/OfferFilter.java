package com.integration.ws.gateway.filter;

import com.integration.json.response.OfferJsonResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.Filter;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 *
 * @author
 */
@Component
public class OfferFilter {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Filter(inputChannel="responseChannel", outputChannel="storeChannel")
    public boolean filterCourse(Message<OfferJsonResponse> msg) {
//        if (!msg.getPayload().getCourseId().startsWith("BC-")) {
//            logger.info("Course [{}] filtered. Not a BF course", msg.getPayload().getCourseId());
//            return false;
//        }
        
       
        return true;
    }
}
