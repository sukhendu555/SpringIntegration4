package com.integration.ws.gateway.request;

/**
 *
 * @author 
 */
public class EmsRequest {
    
}
