
package com.integration.json.request;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "feedback",
    "specialOfferCode",
    "balcon",
    "dynamicOfferEngine",
    "ced",
    "rat",
    "maxFeedback",
    "maxSoc",
    "maxBalcon",
    "maxDoe",
    "maxCed",
    "accountIndicatorForOffers",
    "accountData",
    "corData",
    "location",
    "event",
    "screenId",
    "languageId",
    "relationship"
})
@XmlRootElement
public class CorOfferExtention {

    @JsonProperty("feedback")
    @XmlElement
    private String feedback;
    @JsonProperty("specialOfferCode")
    @XmlElement
    private String specialOfferCode;
    @JsonProperty("balcon")
    @XmlElement
    private String balcon;
    @JsonProperty("dynamicOfferEngine")
    @XmlElement
    private String dynamicOfferEngine;
    @JsonProperty("ced")
    @XmlElement
    private String ced;
    @JsonProperty("rat")
    @XmlElement
    private String rat;
    @JsonProperty("maxFeedback")
    @XmlElement
    private Integer maxFeedback;
    @JsonProperty("maxSoc")
    @XmlElement
    private Integer maxSoc;
    @JsonProperty("maxBalcon")
    @XmlElement
    private Integer maxBalcon;
    @JsonProperty("maxDoe")
    @XmlElement
    private Integer maxDoe;
    @JsonProperty("maxCed")
    @XmlElement
    private Integer maxCed;
    @JsonProperty("accountIndicatorForOffers")
    @XmlElement
    private List<AccountIndicatorForOffer> accountIndicatorForOffers = new ArrayList<AccountIndicatorForOffer>();
    @JsonProperty("accountData")
    @XmlElement
    private List<AccountDatum> accountData = new ArrayList<AccountDatum>();
    @JsonProperty("corData")
    @XmlElement
    private List<CorDatum> corData = new ArrayList<CorDatum>();
    @JsonProperty("location")
    @XmlElement
    private List<Location> location = new ArrayList<Location>();
    @JsonProperty("event")
    @XmlElement
    private String event;
    @JsonProperty("screenId")
    @XmlElement
    private String screenId;
    @JsonProperty("languageId")
    @XmlElement
    private String languageId;
    @JsonProperty("relationship")
    @XmlElement
    private String relationship;
   
    @JsonProperty("feedback")
    public String getFeedback() {
        return feedback;
    }

    @JsonProperty("feedback")
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    @JsonProperty("specialOfferCode")
    public String getSpecialOfferCode() {
        return specialOfferCode;
    }

    @JsonProperty("specialOfferCode")
    public void setSpecialOfferCode(String specialOfferCode) {
        this.specialOfferCode = specialOfferCode;
    }

    @JsonProperty("balcon")
    public String getBalcon() {
        return balcon;
    }

    @JsonProperty("balcon")
    public void setBalcon(String balcon) {
        this.balcon = balcon;
    }

    @JsonProperty("dynamicOfferEngine")
    public String getDynamicOfferEngine() {
        return dynamicOfferEngine;
    }

    @JsonProperty("dynamicOfferEngine")
    public void setDynamicOfferEngine(String dynamicOfferEngine) {
        this.dynamicOfferEngine = dynamicOfferEngine;
    }

    @JsonProperty("ced")
    public String getCed() {
        return ced;
    }

    @JsonProperty("ced")
    public void setCed(String ced) {
        this.ced = ced;
    }

    @JsonProperty("rat")
    public String getRat() {
        return rat;
    }

    @JsonProperty("rat")
    public void setRat(String rat) {
        this.rat = rat;
    }

    @JsonProperty("maxFeedback")
    public Integer getMaxFeedback() {
        return maxFeedback;
    }

    @JsonProperty("maxFeedback")
    public void setMaxFeedback(Integer maxFeedback) {
        this.maxFeedback = maxFeedback;
    }

    @JsonProperty("maxSoc")
    public Integer getMaxSoc() {
        return maxSoc;
    }

    @JsonProperty("maxSoc")
    public void setMaxSoc(Integer maxSoc) {
        this.maxSoc = maxSoc;
    }

    @JsonProperty("maxBalcon")
    public Integer getMaxBalcon() {
        return maxBalcon;
    }

    @JsonProperty("maxBalcon")
    public void setMaxBalcon(Integer maxBalcon) {
        this.maxBalcon = maxBalcon;
    }

    @JsonProperty("maxDoe")
    public Integer getMaxDoe() {
        return maxDoe;
    }

    @JsonProperty("maxDoe")
    public void setMaxDoe(Integer maxDoe) {
        this.maxDoe = maxDoe;
    }

    @JsonProperty("maxCed")
    public Integer getMaxCed() {
        return maxCed;
    }

    @JsonProperty("maxCed")
    public void setMaxCed(Integer maxCed) {
        this.maxCed = maxCed;
    }

    @JsonProperty("accountIndicatorForOffers")
    public List<AccountIndicatorForOffer> getAccountIndicatorForOffers() {
        return accountIndicatorForOffers;
    }

    @JsonProperty("accountIndicatorForOffers")
    public void setAccountIndicatorForOffers(List<AccountIndicatorForOffer> accountIndicatorForOffers) {
        this.accountIndicatorForOffers = accountIndicatorForOffers;
    }

    @JsonProperty("accountData")
    public List<AccountDatum> getAccountData() {
        return accountData;
    }

    @JsonProperty("accountData")
    public void setAccountData(List<AccountDatum> accountData) {
        this.accountData = accountData;
    }

    @JsonProperty("corData")
    public List<CorDatum> getCorData() {
        return corData;
    }

    @JsonProperty("corData")
    public void setCorData(List<CorDatum> corData) {
        this.corData = corData;
    }

    @JsonProperty("location")
    public List<Location> getLocation() {
        return location;
    }

    @JsonProperty("location")
    public void setLocation(List<Location> location) {
        this.location = location;
    }

    @JsonProperty("event")
    public String getEvent() {
        return event;
    }

    @JsonProperty("event")
    public void setEvent(String event) {
        this.event = event;
    }

    @JsonProperty("screenId")
    public String getScreenId() {
        return screenId;
    }

    @JsonProperty("screenId")
    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }

    @JsonProperty("languageId")
    public String getLanguageId() {
        return languageId;
    }

    @JsonProperty("languageId")
    public void setLanguageId(String languageId) {
        this.languageId = languageId;
    }

    @JsonProperty("relationship")
    public String getRelationship() {
        return relationship;
    }

    @JsonProperty("relationship")
    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }
}
