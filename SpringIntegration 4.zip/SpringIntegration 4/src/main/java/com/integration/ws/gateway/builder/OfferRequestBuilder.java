
package com.integration.ws.gateway.builder;

import com.integration.ws.gateway.request.EmsRequest;
import com.integration.json.request.OfferJsonRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 *
 * @author 
 */
@Component
public class OfferRequestBuilder {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @Transformer(inputChannel="requestChannel", outputChannel="invocationChannel")
    public EmsRequest buildRequest(Message<OfferJsonRequest> msg) {
        logger.info("Building request for course [{}]", msg.getPayload());
        OfferJsonRequest inputRequest=msg.getPayload();
       // Build XML request from JSON
        EmsRequest request = new EmsRequest();
       
        
        return request;
    }
}
