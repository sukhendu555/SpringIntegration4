
package com.integration.ws.gateway.response;

/**
 *
 * @author 
 */
public class EmsResponse {
    
}
