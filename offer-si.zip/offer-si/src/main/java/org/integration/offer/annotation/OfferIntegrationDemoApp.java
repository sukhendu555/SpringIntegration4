
package org.integration.offer.annotation;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.integration.offer.OfferType;
import org.integration.offer.Order;
import org.integration.offer.OfferGateway;

/**
 * Provides the 'main' method for running the OfferGateway Demo application. When an
 order is placed, the OfferGateway will send that order to the "orders" channel.
 The channels are defined within the configuration file ("cafeDemo.xml"),
 and the relevant components are configured with annotations (such as the
 OrderSplitter, DrinkRouter, and Barista classes).
 *
 * @author Mark Fisher
 * @author Marius Bogoevici
 */
public class OfferIntegrationDemoApp {

	public static void main(String[] args) {
		AbstractApplicationContext context =
			new ClassPathXmlApplicationContext("/META-INF/spring/integration/cafeDemo-annotation.xml", OfferIntegrationDemoApp.class);

		OfferGateway cafe = (OfferGateway) context.getBean("offerGateway");
		for (int i = 1; i <= 100; i++) {
			Order order = new Order(i);
			order.addItem(OfferType.EMS, 2, false);
			order.addItem(OfferType.FVT, 3, true);
			cafe.placeOrder(order);
		}
		context.close();
	}
}
