

package org.integration.offer.annotation;
import java.util.List;

import org.integration.offer.Order;
import org.integration.offer.OfferItem;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.Splitter;

/**
 * @author Mark Fisher
 */
@MessageEndpoint
public class OfferSplitter {

	@Splitter(inputChannel="orders", outputChannel="drinks")
	public List<OfferItem> split(Order order) {
		return order.getItems();
	}

}
