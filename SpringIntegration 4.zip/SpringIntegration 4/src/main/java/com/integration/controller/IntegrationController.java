package com.integration.controller;

import com.integration.json.request.OfferJsonRequest;
import com.integration.json.response.OfferJsonResponse;
import com.integration.ws.gateway.OfferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author
 */
@RestController
@RequestMapping("/integration")
public class IntegrationController {

    @Autowired
    private OfferService offerService;

    @PostMapping(path = "/liteOffer",consumes =MediaType.APPLICATION_JSON_VALUE,produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<OfferJsonResponse> liteOffer(@RequestBody OfferJsonRequest jsonRequest) {

        try {

            // Call the input Gateway
            OfferJsonResponse response = offerService.findOffer(jsonRequest);

            // Send response back
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
