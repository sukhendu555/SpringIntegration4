package com.integration.ws.gateway.builder;

import com.integration.ws.gateway.response.EmsResponse;
import com.integration.json.response.OfferJsonResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 *
 * @author
 */
@Component
public class OfferResponseBuilder {
    
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    
    @ServiceActivator(inputChannel="responseChannel")
    public OfferJsonResponse getResponse(Message<EmsResponse> msg) {
        EmsResponse emsOfferResp = msg.getPayload();
        logger.info("Course with ID [{}] received: {}", emsOfferResp);
        // Conver XML response from EMS to JSON response
        OfferJsonResponse offerJsonResponse=new OfferJsonResponse();
        
        return offerJsonResponse;
    }
}
